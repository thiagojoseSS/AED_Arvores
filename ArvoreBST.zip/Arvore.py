class Arvore:
    def __init__(self):
        self.__raiz = None

    class No:
        def __init__(self, valor=None):
            self.pai = None
            self.esquerdo = None
            self.direito = None
            self.valor = valor

    def minimo(self, a=None):
        if a is None:
            atual = self.__raiz
        else:
            atual = a
        while atual.esquerdo is not None:
            atual = atual.esquerdo
        return atual.valor

    def maximo(self, a=None):
        if a is None:
            atual = self.__raiz
        else:
            atual = a
        while atual.direito is not None:
            atual = atual.direito
        return atual.valor

    def pred(self, a=None):
        if a is None:
            atual = self.__raiz
        else:
            atual = self.buscar(a)
        atual = atual.esquerdo
        return self.maximo(atual)

    def suce(self, a=None):
        if a is None:
            atual = self.__raiz
        else:
            atual = self.buscar(a)
        atual = atual.direito
        return self.minimo(atual)

    def buscar(self, valor):
        atual = self.__raiz
        while atual is not None and valor != atual.valor:
            if valor < atual.valor:
                atual = atual.esquerdo
            else:
                atual = atual.direito
        return atual

    def buscarRecurcivamente(self, valor, a=None):
        atual = self.__raiz
        if a is not None:
            atual = a
        if valor < atual.valor:
            return self.buscarRecurcivamente(valor, atual.esquerdo)
        elif valor > atual.valor:
            return self.buscarRecurcivamente(valor, atual.direito)
        else:
            return atual.valor

    def inserir(self, valor):
        pai_a = None
        novo = self.No(valor)
        atual = self.__raiz
        while atual is not None:
            pai_a = atual
            if novo.valor < atual.valor:
                atual = atual.esquerdo
            else:
                atual = atual.direito

        novo.pai = pai_a
        if pai_a is None:
            self.__raiz = novo
        elif novo.valor < pai_a.valor:
            pai_a.esquerdo = novo
        else:
            pai_a.direito = novo

    def printCrescente(self, a=None):
        retorna = ""
        if a is None:
            atual = self.__raiz
            retorna += "["
        else:
            atual = a
        # Testando Esquerdo
        if atual.esquerdo is not None:
            retorna += self.printCrescente(atual.esquerdo)
        # Raiz Atual
        m = self.maximo(self.__raiz)
        if m == atual.valor:
            retorna += ("{}]".format(atual.valor))
        else:
            retorna += ("{}, ".format(atual.valor))
        # Testado Direito
        if atual.direito is not None:
            retorna += self.printCrescente(atual.direito)
        return retorna

    def __str__(self):
        return self.printCrescente()

    def __repr__(self):
        return self.__str__()
'''
    def remover(self, valor):
        aremover = self.buscar(valor)
        if aremover.esquerdo is None and aremover.direito is None:
            if aremover.pai is None:
                self.__raiz = None
            else:
                Pai = aremover.pai
                if Pai.esquerdo == aremover:
                    Pai.esquerdo = None
                elif Pai.direito == aremover:
                    Pai.direito = None
                aremover.pai = None
                aremover.valor = None
        elif aremover.direito is not None:
            pass
        else:
            pass
'''
