class Arvore:
    def __init__(self):
        self.__raiz = None

    class No:
        def __init__(self, valor=None):
            self.pai = None
            self.esquerdo = None
            self.direito = None
            self.valor = valor

    def minimo(self, a=None):
        if a is None:
            atual = self.__raiz
        else:
            atual = a
        while atual.esquerdo is not None:
            atual = atual.esquerdo
        return atual

    def maximo(self, a=None):
        if a is None:
            atual = self.__raiz
        else:
            atual = a
        while atual.direito is not None:
            atual = atual.direito
        return atual

    def pred(self, a=None):
        if a is None:
            atual = self.__raiz
        else:
            atual = self.buscar(a)
        atual = atual.esquerdo
        return self.maximo(atual)

    def suce(self, a=None):
        if a is None:
            atual = self.__raiz
        else:
            atual = self.buscar(a)
        atual = atual.direito
        return self.minimo(atual)

    def buscar(self, valor):
        atual = self.__raiz
        while atual is not None and valor != atual.valor:
            if valor < atual.valor:
                atual = atual.esquerdo
            else:
                atual = atual.direito
        return atual

    def buscarRecurcivamente(self, valor, a=None):
        atual = self.__raiz
        if a is not None:
            atual = a
        if valor < atual.valor:
            return self.buscarRecurcivamente(valor, atual.esquerdo)
        elif valor > atual.valor:
            return self.buscarRecurcivamente(valor, atual.direito)
        else:
            return atual.valor

    def inserir(self, valor):
        pai_a = None
        novo = self.No(valor)
        atual = self.__raiz
        while atual is not None:
            pai_a = atual
            if novo.valor < atual.valor:
                atual = atual.esquerdo
            else:
                atual = atual.direito

        novo.pai = pai_a
        if pai_a is None:
            self.__raiz = novo
        elif novo.valor < pai_a.valor:
            pai_a.esquerdo = novo
        else:
            pai_a.direito = novo

    def printCrescente(self, a=None):
        retorna = ""
        if a is None:
            atual = self.__raiz
            retorna += "["
        else:
            atual = a
        # Testando Esquerdo
        if atual.esquerdo is not None:
            retorna += self.printCrescente(atual.esquerdo)
        # Raiz Atual
        m = self.maximo(self.__raiz)
        if m == atual:
            retorna += ("{}]".format(atual.valor))
        else:
            retorna += ("{}, ".format(atual.valor))
        # Testado Direito
        if atual.direito is not None:
            retorna += self.printCrescente(atual.direito)
        return retorna

    def __str__(self):
        return self.printCrescente()

    def __repr__(self):
        return self.__str__()

    def remover(self, valor):
        pai_a = self.__raiz
        atual = self.__raiz
        while atual is not None and valor != atual.valor:
            pai_a = atual
            if valor < atual.valor:
                atual = atual.esquerdo
            else:
                atual = atual.direito

        if atual.esquerdo is None and atual.direito is None:
            if atual == self.__raiz:
                self.__raiz = None
            else:
                if valor < pai_a.valor:
                    pai_a.esquerdo = None
                else:
                    pai_a.direito = None
            atual.pai = None
        elif atual.direito is not None:
            aux = self.suce(atual)
            aux.pai = atual.pai
            if valor < pai_a.valor:
                aux.direito = atual.direito
                atual.esquerdo = None
                aux.esquerdo = atual.esquerdo
                atual.direito = None
                pai_a.esquerdo = aux
            else:
                aux.esquerdo = atual.esquerdo
                atual.direito = None
                aux.direito = atual.direito
                atual.esquerdo = None
                pai_a.direito = aux
            if atual == self.__raiz:
                self.__raiz = aux
            atual.pai = None
        elif atual.esquerdo is not None:
            aux = self.pred(atual)
            aux.pai = atual.pai
            if valor < pai_a.valor:
                aux.direito = atual.direito
                atual.esquerdo = None
                aux.esquerdo = atual.esquerdo
                atual.direito = None
                pai_a.esquerdo = aux
            else:
                aux.esquerdo = atual.esquerdo
                atual.direito = None
                aux.direito = atual.direito
                atual.esquerdo = None
                pai_a.direito = aux
            if atual == self.__raiz:
                self.__raiz = aux
            atual.pai = None
        return print("{} Removido com Sucesso!".format(valor))
