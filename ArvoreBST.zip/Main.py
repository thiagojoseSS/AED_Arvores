from ArvoreBST.Arvore import Arvore

arvore = Arvore()
arvore.inserir(5)
arvore.inserir(3)
arvore.inserir(2)
arvore.inserir(6)

a = arvore.printCrescente()
b = arvore.buscar(5)
c = arvore.__str__()

print(a)
print(b)
print(c)
