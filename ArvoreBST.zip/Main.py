from ArvoreBST.Arvore import Arvore

arvore = Arvore()
arvore.inserir(5)
arvore.inserir(3)
arvore.inserir(2)
arvore.inserir(6)

a = arvore.printCrescente()
b = arvore.suce(5)
c = arvore.pred(5)
d = arvore.buscar(5)
e = arvore.buscarRecurcivamente(2)

print("Ordem Crescente {}".format(a))
print("Sucessor da Raiz {} é {}".format(5, b))
print("Predecessor da Raiz {} é {}".format(5, c))
print("Buscar 5 = {}".format(d))
print("Busca Recursiva = {}".format(e))
