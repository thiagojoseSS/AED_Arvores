from Arvore import Arvore

arvore = Arvore()
print("Inserindo 5, 3, 2 e 6 a arvore.")
arvore.inserir(5)
arvore.inserir(3)
arvore.inserir(2)
arvore.inserir(6)

a = arvore.printCrescente()
b = arvore.suce(5).valor
c = arvore.pred(5).valor
d = arvore.buscar(5).valor
e = arvore.buscarRecurcivamente(2)
print("Ordem Crescente {}".format(a))
print("Sucessor da Raiz {} é {}".format(5, b))
print("Predecessor da Raiz {} é {}".format(5, c))
print("Buscar 5 = {}".format(d))
print("Busca Recursiva = {}".format(e))
f = arvore.remover(6)
print("     Apois Remover o 6 da Arvore!")
g = arvore.printCrescente()
print("Ordem Crescente {}".format(g))
